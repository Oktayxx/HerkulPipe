<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function store(Request $request)
    {
        // Валидация данных
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'company' => 'nullable|string|max:255',
            'phone' => 'required|string|max:15',
            'product_id' => 'required|string|max:255',
        ]);

        // Возвращаем успешный ответ
        return response()->json(['message' => 'Запрос отправлен!'], 200);
    }
}
