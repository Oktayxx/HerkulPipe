<?php

namespace App\Http\Controllers;

class HomePage extends Controller
{
    public function index()
    {
        return 'Herkul pipe';
    }
}
