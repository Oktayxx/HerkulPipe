<?php

use App\Http\Controllers\HomePage;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ContactController;



Route::get('/contact', [ContactController::class, 'showForm']);
Route::post('/contact', [ContactController::class, 'showForm'])->name('contact.store');



Route::get('/', function () {
    return view('welcome');
});

Route::get('/HerkulPipe', [HomePage::class,'index']);
{
    return 'HERKUL PIPE';
}

